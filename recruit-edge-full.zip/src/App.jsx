import RecruitEdge from "./components/RecruitEdge.jsx";

export default function App() {
  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <RecruitEdge />
    </div>
  );
}
